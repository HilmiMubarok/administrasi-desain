<!-- stok bahan -->
<!-- bon bahan -->
<!-- Pesanan -->
<div class="row">
    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 grid-margin stretch-card">
        <div class="card card-statistics">
        <div class="card-body">
            <div class="clearfix">
            <div class="float-left">
                <i class="mdi mdi-cube text-danger icon-lg"></i>
            </div>
            <div class="float-right">
                <p class="mb-0 text-right">Total Stok Bahan</p>
                <div class="fluid-container">
                <h3 class="font-weight-medium text-right mb-0">$65,650</h3>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 grid-margin stretch-card">
        <div class="card card-statistics">
        <div class="card-body">
            <div class="clearfix">
            <div class="float-left">
                <i class="mdi mdi-receipt text-warning icon-lg"></i>
            </div>
            <div class="float-right">
                <p class="mb-0 text-right">Total Bon Bahan</p>
                <div class="fluid-container">
                <h3 class="font-weight-medium text-right mb-0">3455</h3>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 grid-margin stretch-card">
        <div class="card card-statistics">
        <div class="card-body">
            <div class="clearfix">
            <div class="float-left">
                <i class="mdi mdi-poll-box text-success icon-lg"></i>
            </div>
            <div class="float-right">
                <p class="mb-0 text-right">Total Pesanan</p>
                <div class="fluid-container">
                <h3 class="font-weight-medium text-right mb-0">5693</h3>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
</div>