</div>
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Administrasi Desain</a>. All rights reserved.</span>
            </span>
          </div>
        </footer>
      </div>
    </div>
  </div>
</body>

</html>